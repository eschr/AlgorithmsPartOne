import java.util.Arrays;
import java.util.Stack;

public class Board {
	
	private short N;
	private short zeroI;
	private short zeroJ;

	//this 
	private final short[][] board;
	
	//used for generating the neighbor boards
	//private final short[] boardAsArray;
	
	// construct a board from an N-by-N array of blocks
    // (where blocks[i][j] = block in row i, column j)
	// constructs a 1D array and a twin board 
    public Board(int[][] blocks) {
    	
    	N = (short)blocks.length;
    	//boardAsArray = new short[N * N];
    	board = new short[N][N];
  
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			//boardAsArray[N * i + j] = (short) blocks[i][j];
    			board[i][j] = (short) blocks[i][j];
    			if (blocks[i][j] == 0) {
    				zeroI = (short) i;
    				zeroJ = (short) j;
    			}
    		}
    	}
 
    }
    //create new boards by swapping 0 with surrounding values    
    //check current position of 0 to generate valid boards
    //minimum of 2 boards will be generated, max of 4
    //  00 01 02 03
    //  10 11 12 13
    //  20 21 22 23
    //  30 31 32 33
    private void createNeighbors(int zeroI, int zeroJ, int[][] neighbors, Stack<Board> neighborBoards) {
    	//case 00
    	if (zeroI == 0 && zeroJ == 0) {
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case 03
    	else if (zeroI == 0 && zeroJ == N-1) {
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case 30
    	else if (zeroI == N-1 && zeroJ == 0) {
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case 33
    	else if (zeroI == N-1 && zeroJ == N-1) {
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		return;	
    	}
    	//case L side of board
    	else if (zeroJ == 0) {
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case R side of board
    	else if (zeroJ == N-1) {
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case Top of board
    	else if (zeroI == 0) {
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//case Bottom of board
    	else if (zeroI == N-1) {
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		return;
    	}
    	//0 not along any edges of the board
    	//4 exchanges and 4 possible neighbor boards
    	else {
    		neighborBoards.push(exchangeZeroWithLeft(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithRight(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithAbove(zeroI, zeroJ, neighbors));
    		neighborBoards.push(exchangeZeroWithBelow(zeroI, zeroJ, neighbors));
    		return;
    	}
    }
    
    //takes [i][j] = location of 0
    private Board exchangeZeroWithAbove(int i, int j, int[][] neighborBlocks) {
    	int temp = neighborBlocks[i-1][j];
		neighborBlocks[i][j] = temp;
		neighborBlocks[i-1][j] = 0;
		Board b =  new Board(neighborBlocks);
		neighborBlocks[i][j] = 0;
		neighborBlocks[i-1][j] = temp;
		return b;
    }
    
    private Board exchangeZeroWithBelow(int i, int j, int[][] neighborBlocks) {
    	int temp = neighborBlocks[i+1][j];
		neighborBlocks[i][j] = temp;
		neighborBlocks[i+1][j] = 0;
		Board b =  new Board(neighborBlocks);
		neighborBlocks[i][j] = 0;
		neighborBlocks[i+1][j] = temp;
		return b;
    }
    private Board exchangeZeroWithLeft(int i, int j, int[][] neighborBlocks) {
    	int temp = neighborBlocks[i][j-1];
		neighborBlocks[i][j] = temp;
		neighborBlocks[i][j-1] = 0;
		Board b =  new Board(neighborBlocks);
		neighborBlocks[i][j] = 0;
		neighborBlocks[i][j-1] = temp;
		return b;
    }
    private Board exchangeZeroWithRight(int i, int j, int[][] neighborBlocks) {
    	int temp = neighborBlocks[i][j+1];
		neighborBlocks[i][j] = temp;
		neighborBlocks[i][j+1] = 0;
		Board b =  new Board(neighborBlocks);
		neighborBlocks[i][j] = 0;
		neighborBlocks[i][j+1] = temp;
		return b;
    }
    
    //swap pair of blocks to create the twin board
    //will be used to test if the original board is unsolvable
    private void swapPairOfBlocks(int[][] twinBoard) {
    	if( (twinBoard[0][0] != 0) && (twinBoard[0][1] != 0) ) {
    		int temp = twinBoard[0][0];
    		twinBoard[0][0] = twinBoard[0][1];
    		twinBoard[0][1] = temp;
    	}
    	else {
    		int temp = twinBoard[1][0];
    		twinBoard[1][0] = twinBoard[1][1];
    		twinBoard[1][1] = temp;
    	}
    }
    // board dimension N
    public int dimension() {
    	return N;
    }
    
    // number of blocks out of place
    public int hamming() {
    	int count = 0;
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			if(board[i][j] != 0 && board[i][j] != (N*i + j + 1)) count++;
    		}
    	}
    	return count;
    	
    	/*
    	for (int i = 0; i < N * N; i++) {
    		if ( (boardAsArray[i] != (i+1)) && (boardAsArray[i] != 0) ) count++;
    	}
    	return count;*/
    }
    // sum of Manhattan distances between blocks and goal
    public int manhattan()  {
    	int goal_i;
    	int goal_j;
    	int val;
    	int manhattan_sum = 0;
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			if (board[i][j] == 0) continue;
    			val = board[i][j] - 1;
    			goal_i = val / N;
    			goal_j = val % N;
    			manhattan_sum += (Math.abs(goal_i - i) + Math.abs(goal_j - j)); 
    		}
    	}
    	return manhattan_sum;
    }
    // is this board the goal board?
    public boolean isGoal()   {
    	return this.hamming() == 0;
    }
    // a board that is obtained by exchanging any pair of blocks
    public Board twin()  {
    	int[][] twin = new int[N][N];
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			twin[i][j] = board[i][j];
    		}
    	}
    	swapPairOfBlocks(twin);
    	return new Board(twin);
    }
    // does this board equal y?
    public boolean equals(Object y)  {
    	if (y == null) return false;
    	if (this.getClass() != y.getClass()) return false;
    	Board that = (Board) y;
    	for(int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			if (this.board[i][j] != that.board[i][j])
    				return false;
    		}
    	}
    	return true;
    }
 
    public Iterable<Board> neighbors() {
    	Stack<Board> neighborsStack = new Stack<Board>();
    	
    	int[][] neighbors = new int[N][N];
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			neighbors[i][j] = board[i][j];
    		}
    	}
    	createNeighbors(zeroI, zeroJ, neighbors, neighborsStack);
    	return neighborsStack;
    }

    // string representation of this board (in the output format specified below)
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append(N + "\n");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				s.append(String.format("%2d ", board[i][j]));
			}
			s.append("\n");
		}
		return s.toString();
	}

   public static void main(String[] args) {
    	int[][] bricks = {{1, 0, 3},{4, 5, 2},{7, 6, 8}};
    	int[][] bricks2 = {{1, 3, 0},{4, 5, 2},{7, 6, 8}};
    	Board board = new Board(bricks);
    	Board board2 = new Board(bricks2);
    	System.out.println(board.equals(board2));
    	System.out.println(board.hamming());
    	System.out.println(board.manhattan());
    	System.out.println(board.isGoal());
    	System.out.println(board.toString());
    	System.out.println("----------");
    	System.out.println(board.twin().toString());
    	for (Board b : board.neighbors()) {
    		System.out.println(b.toString());
    	}
    	System.out.println(board.toString());
    }
}