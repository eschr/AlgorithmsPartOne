

import java.util.Iterator;

import edu.princeton.cs.algs4.*;

public class Solver {
	
	private MinPQ<SolverNode> minPriorityQue;
	private SolverNode solution;
	private Board original;
	
	private static class SolverNode implements Comparable<SolverNode> {
		private Board board;
		private int priority;
		private int moves;
		private SolverNode previous;
		
		public SolverNode(Board b, int move, SolverNode prev) {
			board = b;
			moves = move;
			priority = b.manhattan() + moves;
			previous = prev;
		}
		
		@Override
		public int compareTo(SolverNode o) {
			if (this.priority < o.priority) 
				return -1;
			if (this.priority > o.priority) 
				return 1;
			if (this.board.hamming() > o.board.hamming()) 
				return -1;
			if (this.board.equals(o.board))
				return 0;
			else return 1;
		}
		
		public void pprint() {
			System.out.println("priority: " + priority);
			System.out.println("moves: " + moves);
			System.out.println("manhattan: " + (priority - moves));
			System.out.print(board.toString());
		}
	}
	
	// find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial)  {
    	if (initial == null) throw new NullPointerException();
    	original = initial;
    	minPriorityQue = new MinPQ<SolverNode>();
    	SolverNode init = new SolverNode(initial, 0, null);
    	SolverNode twinInit = new SolverNode(initial.twin(), 0, null);

    	minPriorityQue.insert(twinInit);
    	minPriorityQue.insert(init);
 
    	while (true) {
    		/*Iterator<SolverNode> iter = minPriorityQue.iterator();
    		while (iter.hasNext()) {
    			iter.next().pprint();
    		}*/
    	
    		solution = minPriorityQue.delMin();
    		
    		if (solution.board.isGoal()) break;
    		
    		for (Board b : solution.board.neighbors()) {
    			if (! thisBoardAlreadyUsed(b, solution)) {
    				minPriorityQue.insert(new SolverNode(b, solution.moves + 1, solution));
    				//System.out.print(movesToSolve + " - " + b.toString());
    			}
    		}
   
   
    	}
    	
    }
    private boolean thisBoardAlreadyUsed(Board b, SolverNode base) {
    	SolverNode curr = base;
    	while (curr.previous != null) {
    		if (curr.board.equals(b) || curr.board.equals(original)) {
    			return true;
    		}
    		curr = curr.previous;
    		
    	}
    	return false;
    }
    
    // is the initial board solvable?
    public boolean isSolvable() {
    	SolverNode cur = solution;
    	while (cur.previous != null) {
    		cur = cur.previous;
    	}
    	if (cur.board.equals(original)) return true;
    	else return false;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
    	if (isSolvable()) return solution.moves;
    	else return -1;
    }
    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution()  {
    	if (! isSolvable() ) return null;
    	
    	Stack<Board> stack = new Stack<Board>();
    	
    	SolverNode cur = solution;
    	while (cur.previous != null) {
    		stack.push(cur.board);
    		cur = cur.previous;
    	}
    	//System.out.println(stack.size());
    	stack.push(cur.board);
    	return stack;
    }
    
    public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
