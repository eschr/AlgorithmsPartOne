import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import edu.princeton.cs.algs4.StdDraw;


public class FastCollinearPoints {
	private ArrayList<LineSegment> lineSegs;
	private int segCount;
	
   public FastCollinearPoints(Point[] points)  {
	   lineSegs = new ArrayList<LineSegment>();
	   segCount = 0;
	   int N = points.length;
	   Arrays.sort(points);
	   Point[] naturalOrder = points.clone();

		for (Point natural : naturalOrder) {
			Arrays.sort(points, natural.slopeOrder());
			int i = 1;
			while (i < N) {
				ArrayList<Point> pointsWithSameSlope = new ArrayList<Point>();
				double currentCompareSlope = natural.slopeTo(points[i]);
				pointsWithSameSlope.add(points[i]);
				int j = i + 1;
				while (j < N && currentCompareSlope == natural.slopeTo(points[j])) {
					pointsWithSameSlope.add(points[j]);
					j++;
				}
				if (pointsWithSameSlope.size() >= 3) {
					if (allPointsLessThanNatural(pointsWithSameSlope, natural)) {
						//System.out.println(natural);
						//pprint(pointsWithSameSlope);
						Collections.sort(pointsWithSameSlope);
						//pprint(pointsWithSameSlope);
						lineSegs.add(new LineSegment(natural, pointsWithSameSlope.get(pointsWithSameSlope.size()-1)));
						segCount++;
					}
				}
				i = j;
			}
		}

   }
   
   private void pprint(ArrayList<Point> p) {
	   for (int i = 0; i < p.size(); i++) {
		   System.out.print(p.get(i) + " ");
	   }
	   System.out.println();
   }
   
   private boolean allPointsLessThanNatural(ArrayList<Point> list, Point natural) {
	   for (Point p: list) {
		   if (natural.compareTo(p) >= 0) return false;
	   }
	   return true;
   }
   
   
   public int numberOfSegments()  {
	   return segCount;
   }
   
   
   public LineSegment[] segments()  {
	   LineSegment[] ls = new LineSegment[lineSegs.size()];
	   lineSegs.toArray(ls);
	   return ls;
	   
   }
   
	/*public static void main(String[] args) {

		// read the N points from a file

		In in = new In(args[0]);
		int N = in.readInt();
		Point[] points = new Point[N];
		for (int i = 0; i < N; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
		}

		// draw the points
		StdDraw.show(0);
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		StdDraw.setPenColor(StdDraw.RED);
		StdDraw.setPenRadius(0.005);
		for (Point p : points) {
			p.draw();
		}
		StdDraw.show();

		// print and draw the line segments
		FastCollinearPoints collinear = new FastCollinearPoints(points);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.setPenRadius(0.002);
		System.out.println(collinear.numberOfSegments());
		for (LineSegment segment : collinear.segments()) {
			StdOut.println(segment);
			segment.draw();
		}
	}*/
}